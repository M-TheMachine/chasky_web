<img src="{{ asset('storage/LOGO-CHASKY-HORIZONTAL.png') }}" alt="{{ config('app.name', 'Laravel') }}" {{ $attributes }} />
